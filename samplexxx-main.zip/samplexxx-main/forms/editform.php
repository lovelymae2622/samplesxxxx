<?php



if($_SERVER["REQUEST_METHOD"] == "POST"){
	include "../db.php";
	$id = $_POST['docid'];
	

	$sql = "SELECT * FROM doctor WHERE docID='$id'";
	$result = mysqli_query($conn, $sql);


		if($result && mysqli_num_rows($result) > 0){
		$row = mysqli_fetch_assoc($result);



?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Edit Info</title>
</head>
<body>

	<div>
		<form method="POST" action="../actions/edit.php">

	
			


			<label>First Name</label><br>
			<input type="text" name="fname" value="<?php echo $row['docFName']; ?>" required><br>

			<label>Last Name</label><br>
			<input type="text" name="lname" value="<?php echo $row['docLName']; ?>" required><br>

			<label> Address</label><br>
			<input type="text" name="address" value="<?php echo $row['docAddress']; ?>" required><br>

			<label>Special</label><br>
			<input type="text" name="special" value="<?php echo $row['docSpecial']; ?>" required><br>

			<input type="hidden" name="docid" value="<?php echo $row['docID']; ?>">

			<button type = "submit">Save Edit</button>
			<button><a href="../pages/doctor.php">Cancel Edit</a></button>
	
		</form>
		
	</div>

</body>
</html>



<?php
}else{
	echo "ERROR ID NOT FOUND";
}



mysqli_close($conn);
}else {
    echo "Access denied. Please access this page through the doctor list.";
}
?>