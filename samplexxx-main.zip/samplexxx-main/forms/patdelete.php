<?php
include "../db.php";


if($_SERVER["REQUEST_METHOD"] == "POST"){
	$id = $_POST['patid'];

	$sql = "SELECT * FROM patient WHERE patID='$id' ";
	$result = $conn->query($sql);

	if($row = mysqli_fetch_assoc($result) ){




}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>DELETE</title>
</head>
<body>
	<h1>are you sure you want to delete <?php echo $row['patFName'] . " ". $row['patLName'];  ?>?</h1>

	<button><a href="../pages/patient.php">NO</a></button>
	<form method="POST" action="../actions/patdelete.php">
		<input type="hidden" name="patid" value = "<?php echo $row['patID']; ?>">
		<input type="submit" value = "YES" >
	</form>
</body>
</html>

<?php  

}
?>