<?php
    include "db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinic Database</title>
</head>
<style>
body {
    font-family: "Inter", Arial, sans-serif;
    background: #f5f7fa;
    margin: 0;
    padding: 40px;
    color: #222;
}

.container {
    max-width: 900px;
    margin: auto;
}

h1 {
    font-size: 28px;
    margin-bottom: 5px;
}

.subtitle {
    color: #777;
    margin-top: 0;
}

.menu-card {
    margin-top: 30px;
    background: white;
    padding: 25px;
    border-radius: 14px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.06);
}

.menu-card h2 {
    margin-bottom: 20px;
    font-size: 20px;
}

.menu-btn {
    display: block;
    width: 90%;
    padding: 15px 18px;
    margin-bottom: 12px;

    background: #f9fafc;
    border-radius: 12px;
    text-decoration: none;
    color: #222;
    font-size: 16px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);

    transition: all 0.2s ease;
}

.menu-btn:hover {
    background: #eef2ff;
    transform: translateY(-2px);
    box-shadow: 0 5px 12px rgba(0,0,0,0.08);
}
</style>
<body>
    <div class="container">
        <h1>Clinic Consultation Logging System</h1>

        <div class="menu-card">
            <a class="menu-btn" href="doctor.php"> Doctors Management</a>
            <a class="menu-btn" href="patients.php"> Patients Management</a>
            <a class="menu-btn" href="consultation.php"> Consultation Transaction Management</a>
        </div>
    </div>
</body>
</html>