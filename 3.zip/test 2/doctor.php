<?php
    include "db.php";

    $sql = "SELECT * FROM doctor";
    $result = $connection->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Management</title>
</head>
<style>
body {
    font-family: "Inter", Arial, sans-serif;
    background: #f5f7fa;
    margin: 0;
    padding: 30px;
}

.page-container {
    max-width: 1000px;
    margin: auto;
    background: #fff;
    padding: 25px;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.06);
}

h2 {
    margin-top: 0;
    margin-bottom: 20px;
    font-size: 26px;
}

.search-bar {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
}

.search-bar input[type="text"] {
    flex: 1;
    padding: 10px 14px;
    border-radius: 8px;
    border: 1px solid #ccc;
}

.btn-primary,
.btn-add {
    padding: 10px 16px;
    background: #536dfe;
    color: white !important;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    text-decoration: none;
    transition: 0.2s;
}

.btn-primary:hover,
.btn-add:hover {
    background: #3d53d4;
}

.styled-table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 12px;
    overflow: hidden;
}

.styled-table th {
    background: #eef1ff;
    padding: 12px;
    text-align: left;
    font-weight: 600;
}

.styled-table td {
    padding: 12px;
    border-bottom: 1px solid #eee;
}

.styled-table tr:hover {
    background: #f6f8ff;
}

.btn-edit,
.btn-delete {
    padding: 6px 12px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    color: white;
    transition: 0.2s;
}

.btn-edit {
    background: #4caf50;
}
.btn-edit:hover {
    background: #3d8e40;
}

.btn-delete {
    background: #f44336;
}
.btn-delete:hover {
    background: #d32f2f;
}
</style>
<body>
    <div class="page-container">
        <h2>Doctor Management</h2>

        <form class="search-bar" action="search.php" method="GET">
            <input type="text" name="query" placeholder="Search patient...">
            <input class="btn-primary" type="submit" value="Search">

            <a class="btn-add" href="forms/adddoctorforms.php">Add Record</a>
        </form>

        <table class="styled-table">
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Address</th>
                <th>Special</th>
                <th colspan="2">Actions</th>
            </tr>

            <?php while($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['docFName']; ?></td>
                <td><?= $row['docLName']; ?></td>
                <td><?= $row['docAddress']; ?></td>
                <td><?= $row['docSpecial']; ?></td>

                <td>
                    <form action="forms/editdoctorforms.php" method="post">
                        <input type="hidden" name="docID" value="<?= $row['docID']; ?>">
                        <button class="btn-edit" type="submit">Edit</button>
                    </form>
                </td>

                <td>
                    <form action="forms/deletedoctorforms.php" method="post">
                        <input type="hidden" name="docID" value="<?= $row['docID']; ?>">
                        <button class="btn-delete" type="submit">Delete</button>
                    </form>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>