<?php
include "../db.php";




?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../css/style.css">
	<title>Add Patient</title>
</head>
<body>
	<h1>Add Patient</h1>

<form method="POST" action="../actions/patadd.php">
	<label>First Name</label><br>
	<input type="text" name = "fname" required><br><br>

	<label>Last Name</label><br>
	<input type="text" name = "lname" required><br><br>

	<label>Date of Birth</label><br>
	<input type="date" name = "bdate" required><br><br>

	<label>Tel number</label><br>
	<input type="text" name = "telno" required><br><br>

	<input type = "submit" value="Add">
</form>
</body>
</html>