<?php

	include "../db.php";

	if($conn){
		echo "your database is connected <br>";
	}else{
		echo "the database in not connected <br>";
	}

if($_SERVER["REQUEST_METHOD"] == "POST"){

	echo $fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$address = $_POST['address'];
	$special = $_POST['special'];


	$sql = "INSERT INTO doctor (docFName, docLName, docaddress, docspecial) 
			VALUES ('$fname', '$lname', '$address', '$special')";


	if($conn->query($sql) === TRUE){
		$conn->close();

		header("Location: ../pages/doctor.php");

		exit();
	}else{
		echo "Error";
	}

}
?>