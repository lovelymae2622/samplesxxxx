<?php

include 'db.php';

$sql = "SELECT * FROM doctor";
$result = mysqli_query($conn, $sql);


?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Clinic</title>
</head>
<style>
    body{
        font-size:16px;
        font-family:Helvetica;
    }

  

</style>
<body>
 <div>
     
     <ul>
         <li><a href="pages/doctor.php">Doctors</a></li>
         <li><a href="pages/patient.php">Patient</a></li>
         <li><a href="pages/consult.php" >Consultation</a></li>
     </ul>
 </div>

</body>
</html>