<?php
    include "../db.php";

    if($_SERVER["REQUEST_METHOD"]=="POST") {

        $ID = $POST['ID'];

        $sql = "SELECT * FROM doctor WHERE docID = '$ID'";
    }
?>