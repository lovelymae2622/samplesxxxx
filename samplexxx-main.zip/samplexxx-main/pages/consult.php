<?php
include "../db.php";

$sql = "SELECT * FROM consultation";
$result = mysqli_query($conn, $sql);




?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Consultation</title>
</head>
<body>
	<button><a href="../index.php">back</a></button>
	<input type="text" name="consearch" >
consultID	patID	docID	consultDate	diagnosis	prescription
	<>
	<table>
		<tr>
			<th>Consult Date</th>
			<th>Diagnosis</th>
			<th>Prescription</th>
		</tr>
		<tr>
			<td></td>
		</tr>
	</table>


</body>
</html>