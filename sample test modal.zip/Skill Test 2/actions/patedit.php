<?php
	include "../db.php";


	if($_SERVER["REQUEST_METHOD"] == "POST"){
		
        $did = $_POST['patID'];
		$fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $bdate = $_POST['bdate'];
        $telno = $_POST['telno'];

		$sql = "UPDATE patient SET patFName = '$fname', patLName = '$lname', patBDate = '$bdate', patTelNo = '$telno' WHERE patID = '$did' ";

		if($connection->query($sql) === TRUE){

			$connection->close();

			header("Location: ../pages/patient.php");

			exit();
		}else{
			echo "ERROR";
		}

	}

?>