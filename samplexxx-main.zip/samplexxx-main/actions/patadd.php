<?php 
include "../db.php";


if($_SERVER["REQUEST_METHOD"] == "POST"){
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$bdate = $_POST['bdate'];
	$telno = $_POST['telno'];

}

$sql = "INSERT INTO patient (patFName, patLName, patBDate, patTelNo)
		VALUES ('$fname', '$lname', '$bdate', '$telno')";

		if($conn->query($sql) === TRUE){
			$conn->close();

			header("Location: ../pages/patient.php");
			exit();

		}else{

			echo "ge pangitaang error";
		}



?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

</body>
</html>