<?php
include "../db.php";

$sql = "SELECT * FROM doctor";
$result = $connection->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Page</title>
    <style>
        body {
            font-family: "Inter", Arial, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 30px;
        }

        .page-container {
            max-width: 1000px;
            margin: auto;
            background: #fff;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.06);
        }

        h2 {
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 26px;
        }

        .search-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .search-bar input[type="text"] {
            flex: 1;
            padding: 10px 14px;
            border-radius: 8px;
            border: 1px solid #ccc;
            min-width: 220px;
        }

        .btn-primary,
        .btn-add,
        .backbtn,
        .btn-close,
        .btn-save {
            padding: 10px 16px;
            background: #536dfe;
            color: white !important;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            transition: 0.2s;
            display: inline-block;
        }

        .btn-primary:hover,
        .btn-add:hover,
        .backbtn:hover,
        .btn-close:hover,
        .btn-save:hover {
            background: #3d53d4;
        }

        .backbtn a {
            color: white;
            text-decoration: none;
        }

        .styled-table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 12px;
            overflow: hidden;
        }

        .styled-table th {
            background: #eef1ff;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }

        .styled-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }

        .styled-table tr:hover {
            background: #f6f8ff;
        }

        .btn-edit,
        .btn-delete {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            color: white;
            transition: 0.2s;
        }

        .btn-edit {
            background: #4caf50;
        }

        .btn-edit:hover {
            background: #3d8e40;
        }

        .btn-delete {
            background: #f44336;
        }

        .btn-delete:hover {
            background: #d32f2f;
        }

        .top-actions {
            margin-bottom: 15px;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.35);
            backdrop-filter: blur(4px);
            justify-content: center;
            align-items: center;
            z-index: 999;
            padding: 20px;
        }

        .modal-content {
            width: 100%;
            max-width: 600px;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.08);
            padding: 25px;
            animation: fadeIn 0.2s ease;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-10px) scale(0.98);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-header h3 {
            margin: 0;
            font-size: 24px;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-size: 15px;
            font-weight: 600;
            color: #333;
        }

        .form-group input {
            width: 100%;
            box-sizing: border-box;
            padding: 12px 14px;
            font-size: 15px;
            border-radius: 8px;
            border: 1px solid #ccc;
            outline: none;
            transition: 0.2s;
        }

        .form-group input:focus {
            border-color: #536dfe;
            box-shadow: 0 0 0 3px rgba(83, 109, 254, 0.12);
        }

        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="page-container">

        <div class="top-actions">
            <button class="backbtn"><a href="../index.php">BACK</a></button>
        </div>

        <h2>Doctor Management</h2>

        <form class="search-bar" action="search.php" method="GET">
            <input type="text" name="query" placeholder="Search doctor...">
            <input class="btn-primary" type="submit" value="Search">

            <button type="button" class="btn-add" onclick="openModal()">Add Doctor</button>
        </form>

        <table class="styled-table">
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Address</th>
                <th>Special</th>
                <th colspan="2">Actions</th>
            </tr>

            <?php while($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['docFName']; ?></td>
                <td><?= $row['docLName']; ?></td>
                <td><?= $row['docAddress']; ?></td>
                <td><?= $row['docSpecial']; ?></td>

                <td>
                    <button 
                        type="button"
                        class="btn-edit"
                        onclick="openEditModal(
                            '<?= $row['docID']; ?>',
                            '<?= htmlspecialchars($row['docFName'], ENT_QUOTES); ?>',
                            '<?= htmlspecialchars($row['docLName'], ENT_QUOTES); ?>',
                            '<?= htmlspecialchars($row['docAddress'], ENT_QUOTES); ?>',
                            '<?= htmlspecialchars($row['docSpecial'], ENT_QUOTES); ?>'
                        )">
                        Edit
                    </button>
                </td>

                <td>
                    <button 
                        type="button"
                        class="btn-delete"
                        onclick="openDeleteModal('<?= $row['docID']; ?>')">
                        Delete
                    </button>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>

    <!-- Add Doctor Modal -->
    <div class="modal" id="doctorModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Add Doctor</h3>
                <button type="button" class="btn-close" onclick="closeModal()">Close</button>
            </div>

            <form action="../actions/add.php" method="POST">
                <div class="form-group">
                    <label for="fname">First Name</label>
                    <input type="text" id="fname" name="fname" placeholder="John" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="lname">Last Name</label>
                    <input type="text" id="lname" name="lname" placeholder="Doe" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="address">Address</label>
                    <input type="text" id="address" name="address" placeholder="MT. View Village, Brgy. Kalunasan, Cebu City" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="special">Specialization</label>
                    <input type="text" id="special" name="special" placeholder="Veterinarian" required autocomplete="off">
                </div>

                <div class="form-actions">
                    <button type="button" class="btn-close" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-save">Add Doctor</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Doctor Modal -->
    <div class="modal" id="editDoctorModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Edit Doctor</h3>
                <button type="button" class="btn-close" onclick="closeEditModal()">Close</button>
            </div>

            <form action="../actions/edit.php" method="POST">
                <input type="hidden" name="docid" id="edit_docid">

                <div class="form-group">
                    <label for="edit_fname">First Name</label>
                    <input type="text" id="edit_fname" name="fname" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="edit_lname">Last Name</label>
                    <input type="text" id="edit_lname" name="lname" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="edit_address">Address</label>
                    <input type="text" id="edit_address" name="address" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="edit_special">Specialization</label>
                    <input type="text" id="edit_special" name="special" required autocomplete="off">
                </div>

                <div class="form-actions">
                    <button type="button" class="btn-close" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn-save">Save Edit</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Doctor Modal -->
    <div class="modal" id="deleteDoctorModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Delete Doctor</h3>
                <button type="button" class="btn-close" onclick="closeDeleteModal()">Close</button>
            </div>

            <p style="margin-bottom:20px; font-size:16px;">
                Are you sure you want to delete this doctor?
            </p>

            <form method="POST" action="../actions/delete.php">
                <input type="hidden" name="id" id="delete_docid">

                <div class="form-actions">
                    <button type="button" class="btn-close" onclick="closeDeleteModal()">Cancel</button>
                    <button type="submit" class="btn-delete">Yes, Delete</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const addModal = document.getElementById("doctorModal");
        const editModal = document.getElementById("editDoctorModal");
        const deleteModal = document.getElementById("deleteDoctorModal");

        function openDeleteModal(id) {
            document.getElementById("delete_docid").value = id;
            deleteModal.style.display = "flex";
        }

        function closeDeleteModal() {
            deleteModal.style.display = "none";
        }

        function openModal() {
            addModal.style.display = "flex";
        }

        function closeModal() {
            addModal.style.display = "none";
        }

        function openEditModal(id, fname, lname, address, special) {
            document.getElementById("edit_docid").value = id;
            document.getElementById("edit_fname").value = fname;
            document.getElementById("edit_lname").value = lname;
            document.getElementById("edit_address").value = address;
            document.getElementById("edit_special").value = special;
            editModal.style.display = "flex";
        }

        function closeEditModal() {
            editModal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target === addModal) closeModal();
            if (event.target === editModal) closeEditModal();
            if (event.target === deleteModal) closeDeleteModal();
        }
    </script>
</body>
</html>