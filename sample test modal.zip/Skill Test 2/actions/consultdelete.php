<?php

include "../db.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){
	$id = $_POST['id'];



	$sql = "DELETE FROM consultation WHERE consultID='$id'";

	if($connection->query($sql)){
		$connection->close();

		header("Location: ../pages/consultation.php");

		exit();

	}else{

		echo "ERROR CAN'T DELETE DATA";
	}

}

?>