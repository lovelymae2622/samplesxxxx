<?php
include "../db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $patID = isset($_POST['patID']) ? trim($_POST['patID']) : '';
    $docID = isset($_POST['docID']) ? trim($_POST['docID']) : '';
    $consultDate = isset($_POST['consultDate']) ? trim($_POST['consultDate']) : '';
    $diagnosis = isset($_POST['diagnosis']) ? trim($_POST['diagnosis']) : '';
    $prescription = isset($_POST['prescription']) ? trim($_POST['prescription']) : '';

    if ($patID === '' || $docID === '' || $consultDate === '' || $diagnosis === '' || $prescription === '') {
        die("Error: All fields are required.");
    }

    $patID = mysqli_real_escape_string($connection, $patID);
    $docID = mysqli_real_escape_string($connection, $docID);
    $consultDate = mysqli_real_escape_string($connection, $consultDate);
    $diagnosis = mysqli_real_escape_string($connection, $diagnosis);
    $prescription = mysqli_real_escape_string($connection, $prescription);

    $checkPatient = mysqli_query($connection, "SELECT patID FROM patient WHERE patID = '$patID'");
    if (!$checkPatient || mysqli_num_rows($checkPatient) == 0) {
        die("Error: Patient does not exist.");
    }

    $checkDoctor = mysqli_query($connection, "SELECT docID FROM doctor WHERE docID = '$docID'");
    if (!$checkDoctor || mysqli_num_rows($checkDoctor) == 0) {
        die("Error: Doctor does not exist.");
    }

    $sql = "INSERT INTO consultation (patID, docID, consultDate, diagnosis, prescription)
            VALUES ('$patID', '$docID', '$consultDate', '$diagnosis', '$prescription')";

    if ($connection->query($sql) === TRUE) {
        $connection->close();
        header("Location: ../pages/consultation.php");
        exit();
    } else {
        echo "Error: " . $connection->error;
    }
} else {
    echo "Access denied.";
}
?>