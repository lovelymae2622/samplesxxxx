<?php
include "../db.php";


if($_SERVER["REQUEST_METHOD"]=="POST"){
	$id = $_POST['patid'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$dob = $_POST['bdate'];
	$telno = $_POST['telno'];


	$sql = "UPDATE patient 
			SET patFName = '$fname', patLName = '$lname', patBDate = '$dob', patTelNo = '$telno' 
			WHERE patID = '$id' ";


		if($conn->query($sql) === TRUE){
					$conn->close;
					header("Location: ../pages/patient.php");
					exit();
			}else{
				echo "error ngani!!";
			}

}


?>