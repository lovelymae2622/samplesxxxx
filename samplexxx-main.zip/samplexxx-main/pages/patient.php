<?php
include "../db.php";

$sql = "SELECT * FROM patient";
$result = mysqli_query($conn, $sql);

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Patient</title>
</head>
<body>
	<button><a href="../index.php" >BACK</a></button>
	<h1>Patients records</h1>

	<input type = "text" >
	<button><a href="../forms/pataddform.php">Add🐶+</a></button>
	<table>
		<tr>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Birth Data</th>
			<th>TelePhone Number</th>
			<th>EDIT</th>
			<th>DELETE</th>

		</tr>
		<?php while($row = mysqli_fetch_assoc($result)) {?>
		<tr>
			

			<td><?php echo $row['patFName']; ?></td>
			<td><?php echo $row['patLName']; ?></td>
			<td><?php echo $row['patBDate']; ?></td>
			<td><?php echo $row['patTelNo']; ?></td>
			<td>
				<form method="POST" action="../forms/patedit.php">
					<input type="hidden" name = "patid"  value="<?php echo $row['patID']; ?>">
					<button type="submit">EDIT</button>
				</form>
			</td>
			<td>
				<form method="POST" action="../forms/patdelete.php">
					<input type="hidden" name = "patid"  value="<?php echo $row['patID']; ?>">
					<button type="submit">DELETE</button>
				</form>
			</td>

		<?php }?>
		</tr>
	</table>

</body>
</html>