<?php

include "../db.php";

$sql = "SELECT * FROM patient";
$result = $connection->query($sql);

// $result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Page</title>
</head>
<style>
        body {
            font-family: "Inter", Arial, sans-serif;
            background: #f5f7fa;
            margin: 0;
            padding: 30px;
        }

        .page-container {
            max-width: 1000px;
            margin: auto;
            background: #fff;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.06);
        }

        h2 {
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 26px;
        }

        .search-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .search-bar input[type="text"] {
            flex: 1;
            padding: 10px 14px;
            border-radius: 8px;
            border: 1px solid #ccc;
            min-width: 220px;
        }

        .btn-primary,
        .btn-add,
        .backbtn,
        .btn-close,
        .btn-save {
            padding: 10px 16px;
            background: #536dfe;
            color: white !important;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            transition: 0.2s;
            display: inline-block;
        }

        .btn-primary:hover,
        .btn-add:hover,
        .backbtn:hover,
        .btn-close:hover,
        .btn-save:hover {
            background: #3d53d4;
        }

        .backbtn a {
            color: white;
            text-decoration: none;
        }

        .styled-table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 12px;
            overflow: hidden;
        }

        .styled-table th {
            background: #eef1ff;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }

        .styled-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }

        .styled-table tr:hover {
            background: #f6f8ff;
        }

        .btn-edit,
        .btn-delete {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            color: white;
            transition: 0.2s;
        }

        .btn-edit {
            background: #4caf50;
        }

        .btn-edit:hover {
            background: #3d8e40;
        }

        .btn-delete {
            background: #f44336;
        }

        .btn-delete:hover {
            background: #d32f2f;
        }

        .top-actions {
            margin-bottom: 15px;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.35);
            backdrop-filter: blur(4px);
            justify-content: center;
            align-items: center;
            z-index: 999;
            padding: 20px;
        }

        .modal-content {
            width: 100%;
            max-width: 600px;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.08);
            padding: 25px;
            animation: fadeIn 0.2s ease;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-10px) scale(0.98);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-header h3 {
            margin: 0;
            font-size: 24px;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-size: 15px;
            font-weight: 600;
            color: #333;
        }

        .form-group input {
            width: 100%;
            box-sizing: border-box;
            padding: 12px 14px;
            font-size: 15px;
            border-radius: 8px;
            border: 1px solid #ccc;
            outline: none;
            transition: 0.2s;
        }

        .form-group input:focus {
            border-color: #536dfe;
            box-shadow: 0 0 0 3px rgba(83, 109, 254, 0.12);
        }

        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
    </style>
<body>
   <div class="page-container">

        <div class="top-actions">
            <button class="backbtn"><a href="../index.php">BACK</a></button>
        </div>

        <h2>Patient Management</h2>

        <form class="search-bar" action="search.php" method="GET">
            <input type="text" name="query" placeholder="Search patient...">
            <input class="btn-primary" type="submit" value="Search">

            <button type="button" class="btn-add" onclick="openModal()">Add Patient</button>
        </form>

        <table class="styled-table">
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Birth Date</th>
                <th>Telephone No.</th>
                <th colspan="2">Actions</th>
            </tr>

        <?php while($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['patFName']; ?></td>
                <td><?= $row['patLName']; ?></td>
                <td><?= $row['patBDate']; ?></td>
                <td><?= $row['patTelNo']; ?></td>

                <td>
                    <button 
                        type="button"
                        class="btn-edit"
                        onclick="openEditModal(
                            '<?= $row['patID']; ?>',
                            '<?= htmlspecialchars($row['patFName'], ENT_QUOTES); ?>',
                            '<?= htmlspecialchars($row['patLName'], ENT_QUOTES); ?>',
                            '<?= htmlspecialchars($row['patBDate'], ENT_QUOTES); ?>',
                            '<?= htmlspecialchars($row['patTelNo'], ENT_QUOTES); ?>'
                        )">
                        Edit
                    </button>
                </td>

                <td>
                    <button 
                        type="button"
                        class="btn-delete"
                        onclick="openDeleteModal('<?= $row['patID']; ?>')">
                        Delete
                    </button>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
        
        
    <!-- Add Patient Modal -->
    <div class="modal" id="patientModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Add Patient</h3>
                <button type="button" class="btn-close" onclick="closeModal()">Close</button>
            </div>

            <form action="../actions/patadd.php" method="POST">
                <div class="form-group">
                    <label for="fname">First Name</label>
                    <input type="text" id="fname" name="fname" placeholder="John" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="lname">Last Name</label>
                    <input type="text" id="lname" name="lname" placeholder="Doe" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="bdate">Birth Date</label>
                    <input type="date" id="bdate" name="bdate" placeholder="1999-01-31" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="telno">Telephone No.</label>
                    <input type="tel" id="telno" name="telno" pattern="[0-9]{11}" placeholder="0917-123-4567" required autocomplete="off"> 
                </div>

                <div class="form-actions">
                    <button type="button" class="btn-close" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-save">Add Patient</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Patient Modal -->
    <div class="modal" id="editPatientModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Edit Patient</h3>
                <button type="button" class="btn-close" onclick="closeEditModal()">Close</button>
            </div>

            <form action="../actions/patedit.php" method="POST">
                <input type="hidden" name="patID" id="edit_patID">

                <div class="form-group">
                    <label for="edit_fname">First Name</label>
                    <input type="text" id="edit_fname" name="fname" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="edit_lname">Last Name</label>
                    <input type="text" id="edit_lname" name="lname" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="edit_bdate">Birth Date</label>
                    <input type="date" id="edit_bdate" name="bdate" required autocomplete="off">
                </div>

                <div class="form-group">
                    <label for="edit_telno">Telephone No.</label>
                    <input type="tel" id="edit_telno" name="telno" required autocomplete="off">
                </div>

                <div class="form-actions">
                    <button type="button" class="btn-close" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn-save">Save Edit</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Patient Modal -->
    <div class="modal" id="deletePatientModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Delete Patient</h3>
                <button type="button" class="btn-close" onclick="closeDeleteModal()">Close</button>
            </div>

            <p style="margin-bottom:20px; font-size:16px;">
                Are you sure you want to delete this patient?
            </p>

            <form method="POST" action="../actions/patdelete.php">
                <input type="hidden" name="id" id="delete_patid">

                <div class="form-actions">
                    <button type="button" class="btn-close" onclick="closeDeleteModal()">Cancel</button>
                    <button type="submit" class="btn-delete">Yes, Delete</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const addModal = document.getElementById("patientModal");
        const editModal = document.getElementById("editPatientModal");
        const deleteModal = document.getElementById("deletePatientModal");

        function openDeleteModal(id) {
            document.getElementById("delete_patid").value = id;
            deleteModal.style.display = "flex";
        }

        function closeDeleteModal() {
            deleteModal.style.display = "none";
        }

        function openModal() {
            addModal.style.display = "flex";
        }

        function closeModal() {
            addModal.style.display = "none";
        }

        function openEditModal(did, fname, lname, bdate, telno) {
            document.getElementById("edit_patID").value = did;
            document.getElementById("edit_fname").value = fname;
            document.getElementById("edit_lname").value = lname;
            document.getElementById("edit_bdate").value = bdate;
            document.getElementById("edit_telno").value = telno;
            editModal.style.display = "flex";
        }

        function closeEditModal() {
            editModal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target === addModal) closeModal();
            if (event.target === editModal) closeEditModal();
            if (event.target === deleteModal) closeDeleteModal();
        }
    </script>
</body>
</html>