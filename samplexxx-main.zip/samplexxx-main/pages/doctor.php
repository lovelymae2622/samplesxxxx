<?php

include '../db.php';

$sql = "SELECT * FROM doctor";
// $result = mysqli_query($conn, $sql);
$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Clinic</title>
</head>

<body>

   <button class="backbtn"><a href="../index.php">back</a></button><h1 class = "head">Doctor records<h1>
   	<div>
    <input type=text autofill=false>
    <button class= "add" id="addbtn" ><a href="../forms/addform.php">Add Doctor</a></button>
	</div>
    <div class = "tablediv">
    <table>
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Address</th>
            <th>Special</th>
            <th>Edit</th>
            <th>Delete</th>
            
        </tr>



        <?php while($row = mysqli_fetch_assoc($result)){ ?>
            <tr>
                <td><?php echo $row['docFName']; ?></td>
                <td><?php echo $row['docLName']; ?></td>
                <td><?php echo $row['docAddress']; ?></td>
                <td><?php echo $row['docSpecial']; ?></td>

                <td>
                	<form method = "POST" action="../forms/editform.php">
                		<input type = "hidden" name = "docid" value = "<?php echo $row['docID']?>">
                 		<button type = "submit" class ="edit" >EDIT</button>
                 	</form> 
             	</td>
                
                <td> 
                	<form method ="POST" action="../forms/deletemess.php">
                		<input type = "hidden" name = "docid" value = "<?php echo $row['docID']?>">
                		<button class ="delete">Delete</button> 
                	</form>
                </td>
              
            </tr>
        <?php } ?>
        
    </table>
   </div>

</body>
<style>
    body{
        text-align:center;
        font-size:16px;
        font-family:Helvetica;
        background-color:#F9FAFC;
    }


    th {
        font-weight:bold;
        font-size: 24px;
        padding-right:10px;
        padding-left:10px;
    }
    td{
        font-size:20px;
        padding-right:10px;
        padding-left:10px;
    }

    input{
        font-size:20px;
        padding-left:10px;
        padding-right:10px;
        margin-left:10px;

    }

    tablediv{
        display:flex;
        justify-content: center;
        align-items:center;
    }

    a{
        text-decoration:none;
    }

    .backbtn{
        left-margin:0;
    }

</style>
</html>