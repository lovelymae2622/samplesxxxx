<?php

include "../db.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){
	$id = $_POST['id'];



	$sql = "DELETE FROM patient WHERE patID='$id'";

	if($connection->query($sql)){
		$connection->close();

		header("Location: ../pages/patient.php");

		exit();

	}else{

		echo "ERROR CAN'T DELETE DATA";
	}

}

?>