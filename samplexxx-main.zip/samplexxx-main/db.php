<?php


$host = "localhost";
$user = "root";
$pass = "";
$database = "clinicdatabase";

$conn = mysqli_connect($host, $user, $pass, $database);




// if($conn){
// 	echo "your database is connected <br>";
// }else{
// 	echo "the database in not connected <br>";
// }



?>
