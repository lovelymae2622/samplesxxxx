-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2026 at 09:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clinic_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `consultation`
--

CREATE TABLE `consultation` (
  `consultID` int(11) NOT NULL,
  `patID` int(11) NOT NULL,
  `docID` int(11) NOT NULL,
  `consultDate` datetime NOT NULL,
  `diagnosis` text NOT NULL,
  `prescription` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consultation`
--

INSERT INTO `consultation` (`consultID`, `patID`, `docID`, `consultDate`, `diagnosis`, `prescription`) VALUES
(1, 1, 1, '2025-01-12 00:00:00', 'Fever and dehydration', 'Paracetamol 500mg, ORS'),
(2, 2, 2, '2025-01-15 00:00:00', 'High blood pressure', 'Amlodipine 5mg daily'),
(3, 3, 3, '2025-01-17 00:00:00', 'Skin allergy', 'Antihistamine, Hydrocortisone cream'),
(4, 4, 4, '2025-01-20 00:00:00', 'Knee pain', 'Ibuprofen 400mg, Rest'),
(5, 5, 5, '2025-01-22 00:00:00', 'Mild flu', 'Vitamin C, Rest, Hydration');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `docID` int(11) NOT NULL,
  `docFName` text NOT NULL,
  `docLName` text NOT NULL,
  `docAddress` text NOT NULL,
  `docSpecial` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`docID`, `docFName`, `docLName`, `docAddress`, `docSpecial`) VALUES
(1, 'Maria', 'Santos', 'Quezon City', 'Pediatrics'),
(2, 'John', 'Reyes', 'Makati City', 'Cardiology'),
(3, 'Ana', 'Cruz', 'Pasig City', 'Dermatology'),
(4, 'Mark', 'Villanueva', 'Manila City', 'Orthopedics'),
(5, 'Sophia', 'Garcia', 'Cebu City', 'General Medicine');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patID` int(11) NOT NULL,
  `patFName` text NOT NULL,
  `patLName` text NOT NULL,
  `patBDate` date NOT NULL,
  `patTelNo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patID`, `patFName`, `patLName`, `patBDate`, `patTelNo`) VALUES
(1, 'Elena', 'Morales', '1998-03-12', '09171234567'),
(2, 'Carlos', 'Delos Santos', '1985-07-22', '09281234567'),
(3, 'Mia', 'Rivera', '2001-11-05', '09391234567'),
(4, 'Joshua', 'Lopez', '1993-09-18', '09471234567'),
(5, 'Hannah', 'Torres', '2000-01-27', '09581234567');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `consultation`
--
ALTER TABLE `consultation`
  ADD PRIMARY KEY (`consultID`),
  ADD KEY `patID` (`patID`),
  ADD KEY `docID` (`docID`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`docID`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`patID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `consultation`
--
ALTER TABLE `consultation`
  MODIFY `consultID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `docID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `patID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `consultation`
--
ALTER TABLE `consultation`
  ADD CONSTRAINT `consultation_ibfk_1` FOREIGN KEY (`patID`) REFERENCES `patient` (`patID`),
  ADD CONSTRAINT `consultation_ibfk_2` FOREIGN KEY (`docID`) REFERENCES `doctor` (`docID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
