<?php
    include "../db.php";

    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $address = $_POST['address'];
        $special = $_POST['special'];

    $sql = "INSERT INTO doctor (docFName, docLName, docAddress, docSpecial)
            VALUES ('$fname','$lname','$address','$special')";
    
        if($connection->query($sql) === TRUE){
            $connection->close();

            header("Location: ../doctor.php");
            
            exit();
        }
    }
?>