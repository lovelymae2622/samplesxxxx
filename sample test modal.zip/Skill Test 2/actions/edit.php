<?php
	include "../db.php";


	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$did = $_POST['docid'];
		$fname = $_POST['fname'];
		$lname = $_POST['lname'];
		$address = $_POST['address'];
		$special = $_POST['special'];


		$sql = "UPDATE doctor SET docFName = '$fname', docLName = '$lname', docAddress = '$address', docSpecial = '$special' WHERE docID = '$did' ";

		if($connection->query($sql) === TRUE){

			$connection->close();

			header("Location: ../pages/doctor.php");

			exit();
		}else{
			echo "ERROR";
		}

	}

?>