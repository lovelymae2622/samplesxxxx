<?php

include "../db.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){

	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$bdate = $_POST['bdate'];
	$telno = $_POST['telno'];

}

	$sql = "INSERT INTO patient (patFName, patLName, patBDate, patTelNo) 
			VALUES ('$fname', '$lname', '$bdate', '$telno')";


	if($connection->query($sql) === TRUE){
		$connection->close();

		header("Location: ../pages/patient.php");
		exit();

	}else{
		echo "Error";
	}

?>