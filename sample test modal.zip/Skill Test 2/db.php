<?php

$hostname = "localhost";
$username = "root";
$password = "";
$database = "clinic_database";

$connection = mysqli_connect ($hostname,$username,$password,$database);

?>