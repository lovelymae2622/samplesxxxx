<?php
    include "../db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Doctor Records</title>
</head>
<body>

        <form action="../actions/add.php" method="post">
            <label for="fname">First Name</label>
                <input name="fname" type="text" value="">
            <label for="lname">Last Name</label>
                <input name="lname" type="text" value="">
            <label for="address">Address</label>
                <input name="address" type="text" value="">
            <label for="special">Special</label>
                <input name="special" type="text" value="">
            
            
            <button type="submit">Add record</button>
        </form>

</body>
</html>