<?php 
include "../db.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){
	$id = $_POST['id'];



	$sql = "DELETE FROM doctor WHERE docID='$id'";

	if($conn->query($sql)){
		$conn->close();

		header("Location: ../pages/doctor.php");

		exit();

	}else{

		echo "ERROR CAN'T DELETE DATA";
	}

}

?>