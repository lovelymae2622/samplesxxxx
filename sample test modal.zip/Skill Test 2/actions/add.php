<?php

include "../db.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){

	echo $fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$address = $_POST['address'];
	$special = $_POST['special'];


	$sql = "INSERT INTO doctor (docFName, docLName, docAddress, docSpecial) 
			VALUES ('$fname', '$lname', '$address', '$special')";


	if($connection->query($sql) === TRUE){
		$connection->close();

		header("Location: ../pages/doctor.php");

		exit();
	}else{
		echo "Error";
	}

}

?>