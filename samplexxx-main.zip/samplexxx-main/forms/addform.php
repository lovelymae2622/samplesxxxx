<?php
include "../db.php";

if($conn){
	echo "your database is connected <br>";
}else{
	echo "the database in not connected <br>";
}
?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Add Doctor</title>
</head>
<style>
	body{
		font-family:Helvetica;
		font-size:16px;

	}
	label{
		font-size:22px;
		font-weight:bold;
	}
	input{
		font-size:20px;
	}
	button{
		font-size:20px;
		text-decoration:none;
	}
	button a{
		font-size:20px;
		text-decoration:none;
	}


</style>

<body>
<button><a href="../pages/doctor.php">Back</a></button>
<div class = "formholder">
	<form action = "../actions/add.php" method = "POST">
		<label>First Name</label><br>
		<input type = "text" name = "fname" placeholder = "john" required autocomplete = "off"><br>

		<label>Last name</label><br>
		<input type = "text" name = "lname" placeholder = "Doe" autocomplete = "off" required><br>

		<label>Address</label><br>
		<input type = "text" name = "address" placeholder = "MT. View Village, brgy. Kalunasan, CEBU CITY" autocomplete = "off" required><br>

		<label>Specialization</label><br>
		<input type = "text" name = "special" placeholder = "Veterenarian" autocomplete = "off" required> <br>


		<button type = "submit">Add</button>
	</form>
	

</div>

</body>
</html>