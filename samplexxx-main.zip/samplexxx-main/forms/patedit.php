<?php
	include "../db.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){

	$id = $_POST['patid'];

	$sql = "SELECT * FROM patient WHERE patID='$id' ";
	$result = mysqli_query($conn, $sql);

	while($row = mysqli_fetch_assoc($result)){

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>EDIT PATIENT</title>
</head>
<body>
	<form method="POST" action="../actions/patedit.php">
		<h1>EDIT PATIENT</h1>

		<input type="hidden" name="patid"  value="<?php echo $row['patID']; ?>"><br>

		<label>PARS NEYM</label><br>
		<input type="text" name="fname"  value="<?php echo $row['patFName']; ?>"><br>

		<label>LAS NEYM</label><br>
		<input type="text" name="lname" value="<?php echo $row['patLName']; ?>"><br>

		<label>DEYT OF BERT</label><br>
		<input type="date" name="bdate" value="<?php echo $row['patBDate']; ?>"><br>

		<label>NAMBIR</label><br>
		<input type="text" name="telno" value="<?php echo $row['patTelNo']; ?>"><br><br>

		<button ><a href="../pages/patient.php" >CANCEL</a></button>
		<input type="submit" values="SAVE">
	</form>


</body>
</html>

<?php

} 
}else{

	echo "ERROR OY AYOHA NA";
}

?>