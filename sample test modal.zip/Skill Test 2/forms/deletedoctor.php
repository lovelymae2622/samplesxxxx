<?php
include "../db.php";


if($_SERVER["REQUEST_METHOD"] == "POST"){
	$id = $_POST['docID'];
	

}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>DELETE FORM</title>
</head>
<body>
	<h1>Are You Sure you Want to delete this?</h1><br>
		<button><a href="../pages/doctor.php">NO</a></button>
	<form method = "POST" action ="../actions/delete.php">
		<input type="hidden" name="id" value="<?php echo $id; ?>">
		
		<button type = "submit">Yes</button>
	</form>
</body> 
</html>