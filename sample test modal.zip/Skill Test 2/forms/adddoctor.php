<?php

include "../db.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADD FORM</title>
</head>
<style>
	body {
        font-family: "Inter", Arial, sans-serif;
        background: #f5f7fa;
        margin: 0;
        padding: 30px;
    }

    .page-container {
        max-width: 1000px;
        margin: auto;
        background: #fff;
        padding: 25px;
        border-radius: 16px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.06);
    }

	label{
		font-size:22px;
		font-weight:bold;
	}
	input{
		font-size:20px;
	}
	button{
		padding: 10px 16px;
        background: #536dfe;
        color: white !important;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        text-decoration: none;
        transition: 0.2s;
	}
	button a{
		font-size:20px;
		text-decoration:none;
	}
</style>
<body>
    <button><a href="../pages/doctor.php"> BACK </a></button>
        <div class = "formholder">
            <form action = "../actions/add.php" method = "POST">
                <label>First Name</label><br>
                <input type = "text" name = "fname" placeholder = "john" required autocomplete = "off"><br>

                <label>Last name</label><br>
                <input type = "text" name = "lname" placeholder = "Doe" autocomplete = "off" required><br>

                <label>Address</label><br>
                <input type = "text" name = "address" placeholder = "MT. View Village, brgy. Kalunasan, CEBU CITY" autocomplete = "off" required><br>

                <label>Specialization</label><br>
                <input type = "text" name = "special" placeholder = "Veterenarian" autocomplete = "off" required> <br>

                <button type = "submit">Add</button>
            </form>
        </div>
</body>
</html>