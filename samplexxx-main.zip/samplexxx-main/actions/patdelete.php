<?php
include "../db.php";

if($_SERVER["REQUEST_METHOD"]== TRUE){

	$id = $_POST['patid'];

	$sql = "DELETE FROM patient WHERE patID='$id' ";

	if($conn->query($sql)=== TRUE){
		$conn->close;
		header("Location: ../pages/patient.php");
		exit();
	}else{
		echo "<h1> ERROR NASAD </h1>";
	}
}

?>