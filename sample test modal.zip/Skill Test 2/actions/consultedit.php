<?php
	include "../db.php";


	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$did = $_POST['consultID'];
		$consDate = $_POST['consultDate'];
        $dia = $_POST['diagnosis'];
        $pres = $_POST['prescription'];


		$sql = "UPDATE consultation SET consultDate = '$consDate', diagnosis = '$dia', prescription = '$pres' WHERE consultID = '$did' ";

		if($connection->query($sql) === TRUE){

			$connection->close();

			header("Location: ../pages/consultation.php");

			exit();
		}else{
			echo "ERROR";
		}

	}

?>